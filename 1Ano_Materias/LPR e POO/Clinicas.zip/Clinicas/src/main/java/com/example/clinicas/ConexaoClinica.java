package com.example.clinicas;
import java.sql.*;

public class ConexaoClinica{

    private Connection conn;
    private PreparedStatement pstmt;
    private ResultSet rs;

    // Método para criar e manter conexão com o banco. Retorna true caso a conexão esteja certa.
    // Retorna false caso algo tenha dado errado.
    public boolean conectar() {
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(
                    "jdbc:postgresql://dpg-ckdivrtjhfbs73bfkf60-a.oregon-postgres.render.com/dbacolhe_3lv1", "acolhe_user", "kjMek6kxSSxFAQFJ6m3NQsWRqRyTh1tz");
            return true; 
        } catch (ClassNotFoundException cnfe) {
            cnfe.printStackTrace();
        } catch (SQLException SQL) {
            SQL.printStackTrace();
        }
        return false;
    }

    // Método para desconectar com o banco.
    public void desconectar(){
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    // Método para inserir uma clínica. Você passa como parâmetro todos os campos.
    // Retorna true caso a inserção tenha ocorrido. Retorna false caso algum erro tenha ocorrido.
    public boolean inserir (int intCodClinica, Clinica clinica){

        if (conectar()) {
            try {

                pstmt = conn.prepareStatement("INSERT INTO CLINICA(codclinica, nmClinica, email, telefone, descricao, imagem, bairro, cidade, nmEstado, sgEstado, patrocinada)VALUES (?,?,?,?,?,?,?,?,?,?,?)");

                pstmt.setInt(1, intCodClinica);
                pstmt.setString(2, clinica.getStrNmClinica());
                pstmt.setString(3, clinica.getStrEmail());
                pstmt.setString(4, clinica.getStrTelefone());
                pstmt.setString(5, clinica.getStrDescricao());
                pstmt.setString(6, clinica.getStrImagem());
                pstmt.setString(7, clinica.getStrBairro());
                pstmt.setString(8, clinica.getStrCidade());
                pstmt.setString(9, clinica.getStrNmEstado());
                pstmt.setString(10, clinica.getStrSgEstado());
                pstmt.setBoolean(11, clinica.getBoolPatrocinada());
                pstmt.execute();

                return true;
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            } finally {
                desconectar();
            }
        } else {
            return false;
        }
    }

    // Método para alterar uma clínica. Você passa como parâmetro o nome do campo que deve
    // ser alterado, o novo valor, o nome do campo que deve ser colocado no where e o valor que deve ser
    // buscado para a alteração.
    // Retorna 1 caso a alteração tenha sido feita. -1 caso tenha ocorrido algum erro e 0 caso nenhuma linha tenha sido alterada.
    public int alterar(String strCampo, Object objNovoValor, String strWhere, Object objBuscar) {

        if (conectar()) {
            try {
                String update = "UPDATE CLINICA SET " + strCampo + " = " + objNovoValor + " WHERE " + strWhere + " = " + objBuscar;
                pstmt = conn.prepareStatement(update);

                if (pstmt.executeUpdate() == 0) {
                    return 0;
                }

                return 1;

            } catch (SQLException e) {
                e.printStackTrace();
                return -1;
            } finally {
                desconectar();
            }
        } else {
            return -1;
        }
    }

    // Método para pegar a última sequência + 1 da tabela Clínica. Retorna um ResultSet com o número.
    // Retorna null caso algum erro tenha ocorrido e o ResultSet caso não tenha dado erro.
    public ResultSet codClinica () {
        if (conectar()) {
            try {
                pstmt = conn.prepareStatement("SELECT MAX(codclinica) + 1 codClinica FROM CLINICA");
                rs = pstmt.executeQuery();

            } catch (SQLException SQL) {
                SQL.printStackTrace();
                return null;
            } finally {
                desconectar();
            }
        } else {
            return null;
        }
        return rs;
    }

}
