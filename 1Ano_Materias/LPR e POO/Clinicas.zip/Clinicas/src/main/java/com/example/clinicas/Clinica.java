package com.example.clinicas;
import java.sql.*;

public class Clinica {

    private int intCodClinica;
    private String strNmClinica, strDescricao, strImagem, strBairro, strCidade, strNmEstado, strSgEstado, strTelefone, strEmail;
    boolean boolPatrocinada;

    // método construtor
    public Clinica(int intCodClinica,
                   String strNmClinica,
                   String strDescricao,
                   String strImagem,
                   String strBairro,
                   String strCidade,
                   String strNmEstado,
                   String strSgEstado,
                   boolean boolPatrocinada,
                   String strTelefone,
                   String strEmail) {
       this.intCodClinica = intCodClinica;
       this.strNmClinica = strNmClinica;
       this.strDescricao = strDescricao;
       this.strImagem = strImagem;
       this.strBairro = strBairro;
       this.strCidade = strCidade;
       this.strNmEstado = strNmEstado;
       this.strSgEstado = strSgEstado;
       this.boolPatrocinada = boolPatrocinada;
       this.strTelefone = strTelefone;
       this.strEmail = strEmail;
    }

    // métodos getters
    public String getStrNmClinica() {
        return this.strNmClinica;
    }

    public String getStrDescricao() {
        return this.strDescricao;
    }

    public String getStrImagem() {
        return this.strImagem;
    }

    public String getStrBairro() {
        return this.strBairro;
    }

    public String getStrCidade() {
        return this.strCidade;
    }

    public String getStrNmEstado() {
        return this.strNmEstado;
    }

    public String getStrSgEstado() {
        return this.strSgEstado;
    }

    public boolean getBoolPatrocinada() {
        return this.boolPatrocinada;
    }

    public String getStrTelefone() {
        return this.strTelefone;
    }

    public String getStrEmail() {
        return this.strEmail;
    }
}
